<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Variant extends Model
{
    use HasFactory;

    protected $primaryKey = 'variant_id';
    public $incrementing = false;
    public $table = 'variants';

    protected $fillable = ['product_id', 'variant_id', 'title', 'price', 'compare_at_price', 'img_src', 'paf',];

    public function product(): BelongsTo
    {
        return $this->belongsTo(Product::class, 'product_id', 'product_id');
    }

    public function getRouteKeyName(): string
{
    return 'variant_id';
}
}
