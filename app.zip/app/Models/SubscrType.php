<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class SubscrType extends Model
{
    use HasFactory;

    protected $table = 'subscr_types';

    protected $fillable = ['name', 'description', 'img_url','status', 'decommissioned_date'];

}
