@php
  $subscriptionType = 'flowers';

  $vendorTypes = [
    'milk_dairy' => 'Milk & Dairy','vegetables'=>'Vegetables','fruits'=>'Fruits','beverages'=>'Beverages',
    'bakery_snacks'=>'Bakery & Snacks','fish_seafood'=>'Fish & Seafood','meat'=>'Meat','flowers'=>'Flowers',
    'groceries'=>'Groceries','puja_samagri'=>'Puja Samagri','chaats_quick_snacks'=>'Chaats & Quick Snacks',
    'sweets_confectionery'=>'Sweets & Confectionery','health_packs'=>'Health Packs','services'=>'Services',
  ];

  $subtypes = ['Loose Flowers','Garlands'];

  $sectionTitle = $vendorTypes[$subscriptionType] . ' — Sub-types';
@endphp

@include('vendor-signup.partials.contract-styles')

@include('vendor-signup.partials.contract-table', [
  'subtypes'            => $subtypes,
  'subscriptionType'    => $subscriptionType,
  'sectionTitle'        => $sectionTitle,
  'mrpCatalog'          => $mrpCatalog ?? [],
  'subtypesSelectedMap' => $subtypesSelectedMap ?? [],
])
