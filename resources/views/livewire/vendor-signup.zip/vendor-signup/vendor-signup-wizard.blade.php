@extends('layouts.app')

@section('content')
{{-- 🔥 include the shared styles for all contract tables --}}
@include('vendor-signup.partials.contract-styles')

{{-- Header with stepper --}}
@include('vendor-signup.partials.header')

{{-- Dynamic middle content --}}
@if($step === 1)
@include('livewire.auth.signin', ['redirectUrl' => route('vendor.signup', ['step' => 2])])
@elseif($step === 2)
@switch($subscriptionType)
@case('milk_dairy') @include('vendor-signup.steps.vendor-milk') @break
@case('vegetables') @include('vendor-signup.steps.vendor-veg') @break
@case('fruits') @include('vendor-signup.steps.vendor-fruits') @break
@case('beverages') @include('vendor-signup.steps.vendor-beverages') @break
@case('bakery_snacks') @include('vendor-signup.steps.vendor-bakery_snacks') @break
@case('fish_seafood') @include('vendor-signup.steps.vendor-fish_seafood') @break
@case('meat') @include('vendor-signup.steps.vendor-meat') @break
@case('flowers') @include('vendor-signup.steps.vendor-flowers') @break
@case('groceries') @include('vendor-signup.steps.vendor-groceries') @break
@case('puja_samagri') @include('vendor-signup.steps.vendor-puja_samagri') @break
@case('chaats_quick_snacks') @include('vendor-signup.steps.vendor-chaats_quick_snacks') @break
@case('sweets_confectionery') @include('vendor-signup.steps.vendor-sweets_confectionery') @break
@case('health_packs') @include('vendor-signup.steps.vendor-health_packs') @break
@default
<div class="alert alert-info">Pick a subscription type to continue.</div>
@endswitch
@elseif($step === 3)
@include('vendor-signup.steps.profile')
@endif

{{-- Footer with nav buttons --}}
@include('vendor-signup.partials.footer')
@endsection