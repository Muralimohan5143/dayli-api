@php
/** @var array $subtypes // e.g. ['Milk','Curd',...]
@var string $subscriptionType // e.g. 'milk_dairy'
@var string $sectionTitle // e.g. 'Milk & Dairy — Sub-types'
@var array $mrpCatalog // e.g. ['milk'=>48, 'curd'=>35, ...]
**/
@endphp

<div class="mt-3">
    <div class="border rounded">
        <div class="px-3 pt-3">
            <h6 class="mb-2 text-uppercase fw-bold" style="color:#2563eb;">
                {{ $sectionTitle }}
            </h6>
        </div>

        <div class="px-3 pb-3">
            <div class="table-responsive">
                <table class="dayli-table table align-middle">
                    <thead>
                        <tr>
                            <th style="min-width:260px;">Name</th>
                            <th>MRP</th>
                            <th>Discount %</th>
                            <th>Discount Amount</th>
                            <th>Cost Price</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($subtypes as $label)
                        @php
                        $key = \Illuminate\Support\Str::slug($label, '_'); // stable key
                        $mrp = $mrpCatalog[$key] ?? 0;
                        $checked = in_array($key, $subtypesSelectedMap[$subscriptionType] ?? []);
                        @endphp

                        <tr
                            x-data="{
                enabled: {{ $checked ? 'true' : 'false' }},
                mrp: {{ $mrp }},
                pct:  @entangle('pricing.'.$key.'.discount_pct').defer,
                amt:  @entangle('pricing.'.$key.'.discount_amt').defer,
                cost: @entangle('pricing.'.$key.'.cost').defer,
                recompute(){
                  if(!this.enabled){ this.cost = ''; return; }
                  const P = Number(this.pct || 0);
                  const A = Number(this.amt || 0);
                  let d = A > 0 ? A : (this.mrp * P/100);
                  if (d < 0) d = 0;
                  if (d > this.mrp) d = this.mrp;
                  this.cost = (this.mrp - d).toFixed(2);
                }
              }"
                            x-init="recompute()"
                            x-effect="recompute()"
                            :class="enabled ? '' : 'is-off'">

                            {{-- NAME + checkbox --}}
                            <td>
                                <label class="d-flex align-items-center gap-2 mb-0">
                                    <input type="checkbox"
                                        @change="enabled = $event.target.checked"
                                        wire:model="subtypesSelectedMap.{{ $subscriptionType }}"
                                        value="{{ $key }}">
                                    <span class="fw-semibold text-dark">{{ $label }}</span>
                                </label>

                                {{-- persist name/mrp keys in payload --}}
                                <input type="hidden" wire:model.defer="pricing.{{ $key }}.name" value="{{ $label }}">
                                <input type="hidden" wire:model.defer="pricing.{{ $key }}.mrp" value="{{ $mrp }}">
                            </td>

                            {{-- MRP (read-only) --}}
                            <td>
                                <input type="number" class="form-control form-control-sm dayli-input text-dark"
                                    :value="mrp" readonly>
                            </td>

                            {{-- Discount % --}}
                            <td>
                                <div class="input-group input-group-sm dayli-input">
                                    <input type="number" min="0" max="100" step="0.01"
                                        class="form-control text-dark" placeholder="%"
                                        x-model="pct" :disabled="!enabled">
                                    <span class="input-group-text">%</span>
                                </div>
                            </td>

                            {{-- Discount Amount --}}
                            <td>
                                <div class="input-group input-group-sm dayli-input">
                                    <span class="input-group-text">₹</span>
                                    <input type="number" min="0" step="0.01"
                                        class="form-control text-dark" placeholder="0.00"
                                        x-model="amt" :disabled="!enabled">
                                </div>
                                <small class="d-block text-dark">If both given, amount wins</small>
                            </td>

                            {{-- Cost Price (read-only) --}}
                            <td>
                                <div class="input-group input-group-sm dayli-input">
                                    <span class="input-group-text">₹</span>
                                    <input type="text" class="form-control text-dark" x-model="cost" readonly>
                                </div>
                            </td>

                        </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>

            <small class="d-block text-dark">
                Tick a sub-type to enable pricing. Cost = MRP − max(Discount Amount, MRP × Discount% / 100).
            </small>
        </div>
    </div>
</div>