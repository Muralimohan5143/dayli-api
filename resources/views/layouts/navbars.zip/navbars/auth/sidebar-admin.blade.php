{{-- Operations --}}
<li class="nav-item mt-2">
  <div class="nav-link text-uppercase text-xs font-weight-bolder text-dark opacity-7">Operations</div>
</li>
<li class="nav-item">
  <a class="nav-link {{ request()->routeIs('sub-change-requests.*') ? 'active' : '' }}" href="{{ route('sub-change-requests.index') }}">
    <i class="ni ni-ruler-pencil"></i><span class="nav-link-text ms-1">CR Change Requests</span>
  </a>
</li>
<li class="nav-item">
  <a class="nav-link {{ request()->routeIs('sub-delivery-actuals.*') ? 'active' : '' }}" href="{{ route('sub-delivery-actuals.index') }}">
    <i class="ni ni-delivery-fast"></i><span class="nav-link-text ms-1">DA Delivery Actuals</span>
  </a>
</li>
<li class="nav-item">
  <a class="nav-link {{ request()->routeIs('zones.index') ? 'active' : '' }}" href="{{ route('zones.index') }}">
    <i class="ni ni-world"></i><span class="nav-link-text ms-1">Zones</span>
  </a>
</li>

{{-- User Management --}}
<li class="nav-item mt-3">
  <div class="nav-link text-uppercase text-xs font-weight-bolder text-dark opacity-7">User Management</div>
</li>
<li class="nav-item">
  <a class="nav-link {{ request()->routeIs('users.*') ? 'active' : '' }}" href="{{ route('users.index') }}">
    <i class="ni ni-single-02"></i><span class="nav-link-text ms-1">Users</span>
  </a>
</li>
<li class="nav-item">
  <a class="nav-link {{ request()->routeIs('roles.*') ? 'active' : '' }}" href="{{ route('roles.index') }}">
    <i class="ni ni-key-25"></i><span class="nav-link-text ms-1">Roles & Permissions</span>
  </a>
</li>

{{-- Technology (admin-specific tools, if any) --}}
<li class="nav-item mt-3">
  <div class="nav-link text-uppercase text-xs font-weight-bolder text-dark opacity-7">Technology</div>
</li>
<li class="nav-item">
  <a class="nav-link {{ request()->routeIs('tech.email-status') ? 'active' : '' }}" href="{{ route('tech.email-status') }}">
    <i class="ni ni-email-83"></i><span class="nav-link-text ms-1">Email Status</span>
  </a>
</li>
<li class="nav-item">
  <a class="nav-link {{ request()->routeIs('tech.platform-health') ? 'active' : '' }}" href="{{ route('tech.platform-health') }}">
    <i class="ni ni-settings"></i><span class="nav-link-text ms-1">Platform Health</span>
  </a>
</li>
