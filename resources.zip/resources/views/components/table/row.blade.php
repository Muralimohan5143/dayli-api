<tr>
    {{ $slot }}
</tr>